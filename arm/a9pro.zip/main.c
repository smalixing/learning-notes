

#define GPF3CON *(volatile unsigned int *)0x114001E0
#define GPF3DAT *(volatile unsigned int *)0x114001E4


void led4_init(void)
{
	GPF3CON = GPF3CON & (~(0xf<<4*4));
	GPF3CON = GPF3CON | (0x1<<4*4);
}
void led4_on(void)
{
	GPF3DAT = GPF3DAT | (0x1<<4);
}
void led4_off(void)
{
	GPF3DAT = GPF3DAT & ~(0x1<<4);
}

void delay(int x)
{
	int i,j;
	for(i=0;i<x;i++){
		for(j=0;j<2000;j++){
			;
		}
	}
}

int main(void)
{	

	led4_init();

	while(1)
	{
		led4_on();
		delay(100);
		led4_off();
		delay(100);
	}

	
	return 0;
}
